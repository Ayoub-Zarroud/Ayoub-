import unittest
import sqlite3

class TestStudentInfoSystem(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Connect to the test database
        cls.connection = sqlite3.connect(':memory:')
        cls.cursor = cls.connection.cursor()
        cls.setup_database()

    @classmethod
    def setup_database(cls):
        # Create test tables
        cls.cursor.execute('''
        CREATE TABLE Students (
            StudentID INTEGER PRIMARY KEY,
            Name TEXT,
            EnrollmentYear INTEGER,
            Major TEXT
        )
        ''')

        cls.cursor.execute('''
        CREATE TABLE Courses (
            CourseID INTEGER PRIMARY KEY,
            CourseName TEXT,
            TeacherID INTEGER
        )
        ''')

        cls.cursor.execute('''
        CREATE TABLE Books (
            BookID INTEGER PRIMARY KEY,
            Title TEXT,
            Price REAL
        )
        ''')

        cls.cursor.execute('''
        CREATE TABLE CourseBooks (
            CourseID INTEGER,
            BookID INTEGER,
            FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
            FOREIGN KEY (BookID) REFERENCES Books(BookID)
        )
        ''')

        cls.cursor.execute('''
        CREATE TABLE StudentCourses (
            StudentID INTEGER,
            CourseID INTEGER,
            Grade REAL,
            FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
            FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
        )
        ''')

        cls.cursor.execute('''
        CREATE TABLE StudentBooks (
            StudentID INTEGER,
            BookID INTEGER,
            FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
            FOREIGN KEY (BookID) REFERENCES Books(BookID)
        )
        ''')

        cls.cursor.execute('''
        CREATE TABLE Teachers (
            TeacherID INTEGER PRIMARY KEY,
            FirstName TEXT
        )
        ''')

        # Insert test data
        cls.cursor.execute("INSERT INTO Students (StudentID, Name, EnrollmentYear, Major) VALUES (1, 'John Doe', 2020, 'Computer Science')")
        cls.cursor.execute("INSERT INTO Courses (CourseID, CourseName, TeacherID) VALUES (1, 'CS101', 1)")
        cls.cursor.execute("INSERT INTO Books (BookID, Title, Price) VALUES (1, 'Computer Science 101', 100.0)")
        cls.cursor.execute("INSERT INTO CourseBooks (CourseID, BookID) VALUES (1, 1)")
        cls.cursor.execute("INSERT INTO StudentCourses (StudentID, CourseID, Grade) VALUES (1, 1, 3.5)")
        cls.cursor.execute("INSERT INTO Teachers (TeacherID, FirstName) VALUES (1, 'Jane Smith')")
        cls.connection.commit()

    def test_list_all_students_and_majors(self):
        query = 'SELECT Name, Major FROM Students'
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        expected = [('John Doe', 'Computer Science')]
        self.assertEqual(results, expected)

    def test_get_student_number(self):
        query = 'SELECT COUNT(*) FROM Students'
        self.cursor.execute(query)
        results = self.cursor.fetchone()[0]
        expected = 1
        self.assertEqual(results, expected)

    def test_get_books_by_course(self):
        query = '''
        SELECT b.Title, b.Price
        FROM Books b
        JOIN CourseBooks cb ON b.BookID = cb.BookID
        WHERE cb.CourseID = ?
        '''
        self.cursor.execute(query, (1,))
        results = self.cursor.fetchall()
        expected = [('Computer Science 101', 100.0)]
        self.assertEqual(results, expected)

    def test_register_for_course(self):
        query = 'INSERT INTO StudentCourses (StudentID, CourseID) VALUES (?, ?)'
        self.cursor.execute(query, (1, 2))
        self.connection.commit()
        query = 'SELECT * FROM StudentCourses WHERE StudentID = 1 AND CourseID = 2'
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        self.assertEqual(len(results), 1)

    def test_update_student_info(self):
        query = 'UPDATE Students SET Name = ?, EnrollmentYear = ?, Major = ? WHERE StudentID = ?'
        self.cursor.execute(query, ('Jane Doe', 2021, 'Biology', 1))
        self.connection.commit()
        query = 'SELECT Name, EnrollmentYear, Major FROM Students WHERE StudentID = ?'
        self.cursor.execute(query, (1,))
        results = self.cursor.fetchone()
        expected = ('Jane Doe', 2021, 'Biology')
        self.assertEqual(results, expected)

    @classmethod
    def tearDownClass(cls):
        cls.connection.close()

if __name__ == '__main__':
    unittest.main()
