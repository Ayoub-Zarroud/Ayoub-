import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

connection = sqlite3.connect('db/student_info_system.db')
cursor = connection.cursor()

def execute_query(query, params=()):
    try:
        cursor.execute(query, params)
        connection.commit()
        return cursor.fetchall()
    except sqlite3.Error as e:
        messagebox.showerror("Error", str(e))
        return []

def update_treeview(tree, results, columns):
    tree.delete(*tree.get_children())
    tree["columns"] = columns
    tree["show"] = "headings"
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=100)
    for result in results:
        tree.insert("", "end", values=result)

def choose_course(student_id, course_id):
    query = '''
    INSERT INTO StudentCourses (StudentID, CourseID)
    VALUES (?, ?)
    '''
    execute_query(query, (student_id, course_id))
    messagebox.showinfo("Success", "Course chosen successfully!")
    display_all_students()

def manage_accommodation(student_id, accommodation_info):
    query = '''
    UPDATE Students
    SET Accommodation = ?
    WHERE StudentID = ?
    '''
    execute_query(query, (accommodation_info, student_id))
    messagebox.showinfo("Success", "Accommodation information updated successfully!")
    display_all_students()

def buy_books(student_id, course_id):
    query = '''
    SELECT b.Title
    FROM Books b
    JOIN CourseBooks cb ON b.BookID = cb.BookID
    WHERE cb.CourseID = ?
    '''
    results = execute_query(query, (course_id,))
    books = [book[0] for book in results]
    book_list = "\n".join(books)
    messagebox.showinfo("Books", f"Books for Course ID {course_id}:\n{book_list}")

def register_update_student(student_id, name, enrollment_year, major):
    query = '''
    INSERT INTO Students (StudentID, Name, EnrollmentYear, Major)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(StudentID) DO UPDATE SET
    Name = excluded.Name,
    EnrollmentYear = excluded.EnrollmentYear,
    Major = excluded.Major
    '''
    execute_query(query, (student_id, name, enrollment_year, major))
    messagebox.showinfo("Success", "Student information registered/updated successfully!")
    display_all_students()

def display_all_students():
    query = 'SELECT * FROM Students'
    results = execute_query(query)
    columns = ["StudentID", "Name", "EnrollmentYear", "Major"]
    update_treeview(result_tree, results, columns)

def validate_login(name, student_id):
    query = '''
    SELECT * FROM Students WHERE Name = ? AND StudentID = ?
    '''
    results = execute_query(query, (name, student_id))
    if results:
        show_main_app(student_id)
    else:
        messagebox.showerror("Error", "Invalid name or student ID")

def show_main_app(student_id):
    login_frame.pack_forget()
    main_frame.pack(fill=tk.BOTH, expand=True)
    display_all_students()

app = tk.Tk()
app.title("Student Information System")

login_frame = tk.Frame(app)
login_frame.pack(fill=tk.BOTH, expand=True)

tk.Label(login_frame, text="Name").grid(row=0, column=0)
name_entry = tk.Entry(login_frame)
name_entry.grid(row=0, column=1)

tk.Label(login_frame, text="Student ID").grid(row=1, column=0)
student_id_entry = tk.Entry(login_frame)
student_id_entry.grid(row=1, column=1)

tk.Button(login_frame, text="Login", command=lambda: validate_login(name_entry.get(), student_id_entry.get())).grid(row=2, column=1)

main_frame = tk.Frame(app)

function_frame = tk.Frame(main_frame)
function_frame.pack(fill=tk.BOTH, expand=True)

tk.Label(function_frame, text="Student ID").grid(row=0, column=0)
student_id_function_entry = tk.Entry(function_frame)
student_id_function_entry.grid(row=0, column=1)

tk.Label(function_frame, text="Course ID").grid(row=1, column=0)
course_id_entry = tk.Entry(function_frame)
course_id_entry.grid(row=1, column=1)
tk.Button(function_frame, text="Choose Course", command=lambda: choose_course(student_id_function_entry.get(), course_id_entry.get())).grid(row=1, column=2)

tk.Label(function_frame, text="Accommodation Info").grid(row=2, column=0)
accommodation_entry = tk.Entry(function_frame)
accommodation_entry.grid(row=2, column=1)
tk.Button(function_frame, text="Update Accommodation", command=lambda: manage_accommodation(student_id_function_entry.get(), accommodation_entry.get())).grid(row=2, column=2)
tk.Button(function_frame, text="Buy Books", command=lambda: buy_books(student_id_function_entry.get(), course_id_entry.get())).grid(row=3, column=1)

tk.Label(function_frame, text="Name").grid(row=4, column=0)
name_function_entry = tk.Entry(function_frame)
name_function_entry.grid(row=4, column=1)
tk.Label(function_frame, text="Enrollment Year").grid(row=5, column=0)
enrollment_year_entry = tk.Entry(function_frame)
enrollment_year_entry.grid(row=5, column=1)
tk.Label(function_frame, text="Major").grid(row=6, column=0)
major_entry = tk.Entry(function_frame)
major_entry.grid(row=6, column=1)
tk.Button(function_frame, text="Register/Update Info", command=lambda: register_update_student(student_id_function_entry.get(), name_function_entry.get(), enrollment_year_entry.get(), major_entry.get())).grid(row=7, column=1)

result_frame = tk.Frame(main_frame)
result_frame.pack(fill=tk.BOTH, expand=True)

result_tree = ttk.Treeview(result_frame)
result_tree.pack(fill=tk.BOTH, expand=True)

tk.Button(main_frame, text="Display All Students", command=display_all_students).pack()

app.mainloop()
connection.close()
