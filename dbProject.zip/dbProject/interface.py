import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

connection = sqlite3.connect('db/student_info_system.db')
cursor = connection.cursor()

def execute_query(query, params=()):
    try:
        cursor.execute(query, params)
        results = cursor.fetchall()
        return results
    except sqlite3.Error as e:
        messagebox.showerror("Error", str(e))
        return []

def list_all_students_and_majors():
    query = '''
    SELECT Name, Major 
    FROM Students
    '''
    return execute_query(query)

def get_student_number():
    query = 'SELECT COUNT(*) FROM Students'
    return execute_query(query)

def get_biology_student_number():
    query = "SELECT COUNT(*) FROM Students WHERE Major = 'Biology'"
    return execute_query(query)

def get_books_by_course():
    query = '''
    SELECT c.CourseName, b.Title
    FROM Courses c
    JOIN CourseBooks cb ON c.CourseID = cb.CourseID
    JOIN Books b ON cb.BookID = b.BookID
    '''
    return execute_query(query)

def students_enrolled_in_each_course():
    query = '''
    SELECT c.CourseName, s.Name
    FROM Courses c
    JOIN StudentCourses sc ON c.CourseID = sc.CourseID
    JOIN Students s ON sc.StudentID = s.StudentID
    '''
    return execute_query(query)

def get_student_courses_and_grades():
    query = '''
    SELECT s.Name, c.CourseName, sc.Grade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    JOIN Courses c ON sc.CourseID = c.CourseID
    '''
    return execute_query(query)

def courses_taught_by_each_teacher():
    query = '''
    SELECT t.FirstName, c.CourseName
    FROM Teachers t
    JOIN Courses c ON t.TeacherID = c.TeacherID
    '''
    return execute_query(query)

def teacher_courses_and_student_count():
    query = '''
    SELECT t.FirstName, c.CourseName, COUNT(sc.StudentID) as StudentCount
    FROM Teachers t
    JOIN Courses c ON t.TeacherID = c.TeacherID
    JOIN StudentCourses sc ON c.CourseID = sc.CourseID
    GROUP BY t.FirstName, c.CourseName
    '''
    return execute_query(query)

def teachers_not_teaching_any_course():
    query = '''
    SELECT FirstName
    FROM Teachers
    WHERE TeacherID NOT IN (SELECT DISTINCT TeacherID FROM Courses)
    '''
    return execute_query(query)

def teachers_with_highest_student_count():
    query = '''
    SELECT t.FirstName, COUNT(sc.StudentID) as StudentCount
    FROM Teachers t
    JOIN Courses c ON t.TeacherID = c.TeacherID
    JOIN StudentCourses sc ON c.CourseID = sc.CourseID
    GROUP BY t.FirstName
    ORDER BY StudentCount DESC
    LIMIT 3
    '''
    return execute_query(query)

def get_average_grade_by_course():
    query = '''
    SELECT CourseID, AVG(Grade) as AverageGrade
    FROM StudentCourses
    GROUP BY CourseID
    '''
    return execute_query(query)

def students_not_enrolled_in_any_course():
    query = '''
    SELECT Name 
    FROM Students
    WHERE StudentID NOT IN (SELECT DISTINCT StudentID FROM StudentCourses)
    '''
    return execute_query(query)

def get_student_count_by_course():
    query = '''
    SELECT CourseID, COUNT(StudentID) as StudentCount
    FROM StudentCourses
    GROUP BY CourseID
    '''
    return execute_query(query)

def get_average_grade_by_student():
    query = '''
    SELECT StudentID, AVG(Grade) as AverageGrade
    FROM StudentCourses
    GROUP BY StudentID
    '''
    return execute_query(query)

def average_grade_per_student_in_each_course():
    query = '''
    SELECT s.Name, c.CourseName, AVG(sc.Grade) as AverageGrade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    JOIN Courses c ON sc.CourseID = c.CourseID
    GROUP BY s.Name, c.CourseName
    '''
    return execute_query(query)

def top_three_students_with_highest_average_grades():
    query = '''
    SELECT s.Name, AVG(sc.Grade) as AverageGrade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    GROUP BY s.Name
    ORDER BY AverageGrade DESC
    LIMIT 3
    '''
    return execute_query(query)

def students_with_lowest_average_grade():
    query = '''
    SELECT s.Name, AVG(sc.Grade) as AverageGrade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    GROUP BY s.Name
    ORDER BY AverageGrade ASC
    LIMIT 3
    '''
    return execute_query(query)

def books_not_associated_with_any_course():
    query = '''
    SELECT Title
    FROM Books
    WHERE BookID NOT IN (SELECT DISTINCT BookID FROM CourseBooks)
    '''
    return execute_query(query)

def books_required_for_each_major():
    query = '''
    SELECT s.Major, b.Title
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    JOIN Courses c ON sc.CourseID = c.CourseID
    JOIN CourseBooks cb ON c.CourseID = cb.CourseID
    JOIN Books b ON cb.BookID = b.BookID
    '''
    return execute_query(query)

def get_all_students():
    query = 'SELECT * FROM Students'
    return execute_query(query)

def update_treeview(tree, results, columns):
    tree.delete(*tree.get_children())
    tree["columns"] = columns
    tree["show"] = "headings"
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=100)
    for result in results:
        tree.insert("", "end", values=result)

def handle_query(query_func, tree, columns):
    results = query_func()
    update_treeview(tree, results, columns)

app = tk.Tk()
app.title("Student Information System")

left_frame = tk.Frame(app)
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

student_tree = ttk.Treeview(left_frame)
student_tree.pack(fill=tk.BOTH, expand=True)

student_columns = ["StudentID", "Name", "EnrollmentYear", "Major"]
student_data = get_all_students()
update_treeview(student_tree, student_data, student_columns)

right_frame = tk.Frame(app)
right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

result_tree = ttk.Treeview(right_frame)
result_tree.pack(fill=tk.BOTH, expand=True)

button_frame = tk.Frame(right_frame)
button_frame.pack(fill=tk.X)


tk.Button(button_frame, text="All Students & Majors", command=lambda: handle_query(list_all_students_and_majors, result_tree, ["Name", "Major"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Total Students", command=lambda: handle_query(get_student_number, result_tree, ["Count"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Biology Students", command=lambda: handle_query(get_biology_student_number, result_tree, ["Count"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Books by Course", command=lambda: handle_query(get_books_by_course, result_tree, ["CourseName", "Title"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Students in Each Course", command=lambda: handle_query(students_enrolled_in_each_course, result_tree, ["CourseName", "Name"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Student Courses & Grades", command=lambda: handle_query(get_student_courses_and_grades, result_tree, ["Name", "CourseName", "Grade"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Courses by Teacher", command=lambda: handle_query(courses_taught_by_each_teacher, result_tree, ["FirstName", "CourseName"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Teacher Courses & Student Count", command=lambda: handle_query(teacher_courses_and_student_count, result_tree, ["FirstName", "CourseName", "StudentCount"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Teachers Not Teaching", command=lambda: handle_query(teachers_not_teaching_any_course, result_tree, ["FirstName"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Top Teachers by Student Count", command=lambda: handle_query(teachers_with_highest_student_count, result_tree, ["FirstName", "StudentCount"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Average Grade by Course", command=lambda: handle_query(get_average_grade_by_course, result_tree, ["CourseID", "AverageGrade"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Students Not Enrolled", command=lambda: handle_query(students_not_enrolled_in_any_course, result_tree, ["Name"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Student Count by Course", command=lambda: handle_query(get_student_count_by_course, result_tree, ["CourseID", "StudentCount"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Average Grade by Student", command=lambda: handle_query(get_average_grade_by_student, result_tree, ["StudentID", "AverageGrade"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Avg Grade per Student/Course", command=lambda: handle_query(average_grade_per_student_in_each_course, result_tree, ["Name", "CourseName", "AverageGrade"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Top 3 Students by Avg Grade", command=lambda: handle_query(top_three_students_with_highest_average_grades, result_tree, ["Name", "AverageGrade"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Lowest 3 Students by Avg Grade", command=lambda: handle_query(students_with_lowest_average_grade, result_tree, ["Name", "AverageGrade"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Books Not Associated", command=lambda: handle_query(books_not_associated_with_any_course, result_tree, ["Title"])).pack(side=tk.LEFT)
tk.Button(button_frame, text="Books Required by Major", command=lambda: handle_query(books_required_for_each_major, result_tree, ["Major", "Title"])).pack(side=tk.LEFT)

app.mainloop()
connection.close()
