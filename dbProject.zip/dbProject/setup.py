#  ____       _                 _   __  __                                                   _     ____            _                 
# / ___|  ___| |__   ___   ___ | | |  \/  | __ _ _ __   __ _  __ _  ___ _ __ ___   ___ _ __ | |_  / ___| _   _ ___| |_ ___ _ __ ___  
# \___ \ / __| '_ \ / _ \ / _ \| | | |\/| |/ _` | '_ \ / _` |/ _` |/ _ | '_ ` _ \ / _ | '_ \| __| \___ \| | | / __| __/ _ | '_ ` _ \ 
#  ___) | (__| | | | (_) | (_) | | | |  | | (_| | | | | (_| | (_| |  __| | | | | |  __| | | | |_   ___) | |_| \__ | ||  __| | | | | |
# |____/ \___|_| |_|\___/ \___/|_| |_|  |_|\__,_|_| |_|\__,_|\__, |\___|_| |_| |_|\___|_| |_|\__| |____/ \__, |___/\__\___|_| |_| |_|
#                                                            |___/                                       |___/                         


import sqlite3

def create_students_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Students (
            StudentID INT PRIMARY KEY,
            Name TEXT,
            EnrollmentYear INT,
            Major TEXT,
            Gender TEXT,
            Age INT
        )
    ''')

def create_books_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Books (
            BookID INT PRIMARY KEY,
            Title TEXT,
            Price INT
        )
    ''')

def create_teachers_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Teachers (
            TeacherID INT PRIMARY KEY,
            FirstName TEXT,
            LastName TEXT,
            Email TEXT
        )
    ''')

def create_courses_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Courses (
            CourseID INT PRIMARY KEY,
            CourseName TEXT,
            TeacherID INT,
            Major TEXT,
            FOREIGN KEY (TeacherID) REFERENCES Teachers(TeacherID)
        )
    ''')

def create_student_courses_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS StudentCourses (
            StudentID INT,
            CourseID INT,
            Grade INT,
            PRIMARY KEY (StudentID, CourseID),
            FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
            FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
        )
    ''')

def create_course_books_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS CourseBooks (
            CourseID INT,
            BookID INT,
            PRIMARY KEY (CourseID, BookID),
            FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
            FOREIGN KEY (BookID) REFERENCES Books(BookID)
        )
    ''')

def initialize_database():
    with sqlite3.connect('db/student_info_system.db') as connection:
        cursor = connection.cursor()
        create_students_table(cursor)
        create_books_table(cursor)
        create_teachers_table(cursor)
        create_courses_table(cursor)
        create_student_courses_table(cursor)
        create_course_books_table(cursor)
        connection.commit()

initialize_database()
print("Database created successfully")
