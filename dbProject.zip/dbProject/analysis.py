import sqlite3

connection = sqlite3.connect('db\student_info_system.db')
cursor = connection.cursor()
def listAllStudentsAndMajors():
    cursor.execute('''
    SELECT Name, Major 
    FROM Students
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
listAllStudentsAndMajors()

def studentNumber():
    cursor.execute('''
    select count(*) from Students
    ''')
    numbers = cursor.fetchall()
    for number in numbers:
        print(number)
studentNumber()  

def biologyStudentNumber():
    cursor.execute('''
    select Major , count(Major) from Students
    where Major = 'Biology'
    ''')
    numbers = cursor.fetchall()
    for number in numbers:
        print(number)
biologyStudentNumber()

def booksByCourse():
    cursor.execute('''
    SELECT c.CourseName, b.Title
    FROM Courses c
    JOIN CourseBooks cb ON c.CourseID = cb.CourseID
    JOIN Books b ON cb.BookID = b.BookID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
booksByCourse()

def studentsEnrolledInEachCourse():
    cursor.execute('''
    SELECT c.CourseName, s.Name
    FROM Courses c
    JOIN StudentCourses sc ON c.CourseID = sc.CourseID
    JOIN Students s ON sc.StudentID = s.StudentID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
studentsEnrolledInEachCourse()

def studentCoursesAndGrades():
    cursor.execute('''
    SELECT s.Name, c.CourseName, sc.Grade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    JOIN Courses c ON sc.CourseID = c.CourseID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
studentCoursesAndGrades()

def coursesTaughtByEachTeacher():
    cursor.execute('''
    SELECT t.FirstName, c.CourseName
    FROM Teachers t
    JOIN Courses c ON t.TeacherID = c.TeacherID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
coursesTaughtByEachTeacher()

def teacherCoursesAndStudentCount():
    cursor.execute('''
    SELECT t.FirstName, c.CourseName, COUNT(sc.StudentID) as StudentCount
    FROM Teachers t
    JOIN Courses c ON t.TeacherID = c.TeacherID
    JOIN StudentCourses sc ON c.CourseID = sc.CourseID
    GROUP BY t.FirstName, c.CourseName
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
teacherCoursesAndStudentCount()

def teachersNotTeachingAnyCourse():
    cursor.execute('''
    SELECT FirstName
    FROM Teachers
    WHERE TeacherID NOT IN (SELECT DISTINCT TeacherID FROM Courses)
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
teachersNotTeachingAnyCourse()

def teachersWithHighestStudentCount():
    cursor.execute('''
    SELECT t.FirstName, COUNT(sc.StudentID) as StudentCount
    FROM Teachers t
    JOIN Courses c ON t.TeacherID = c.TeacherID
    JOIN StudentCourses sc ON c.CourseID = sc.CourseID
    GROUP BY t.FirstName
    ORDER BY StudentCount DESC
    LIMIT 3
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
teachersWithHighestStudentCount()


def averageGradeByCourse():
    cursor.execute('''
    SELECT CourseID, AVG(Grade) as AverageGrade
    FROM StudentCourses
    GROUP BY CourseID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
averageGradeByCourse()

def studentsNotEnrolledInAnyCourse():
    cursor.execute('''
    SELECT Name 
    FROM Students
    WHERE StudentID NOT IN (SELECT DISTINCT StudentID FROM StudentCourses)
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
studentsNotEnrolledInAnyCourse()


def studentCountByCourse():
    cursor.execute('''
    SELECT CourseID, COUNT(StudentID) as StudentCount
    FROM StudentCourses
    GROUP BY CourseID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)

studentCountByCourse()

def averageGradeByStudent():
    cursor.execute('''
    SELECT StudentID, AVG(Grade) as AverageGrade
    FROM StudentCourses
    GROUP BY StudentID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)

averageGradeByStudent()

def averageGradePerStudentInEachCourse():
    cursor.execute('''
    SELECT s.Name, c.CourseName, AVG(sc.Grade) as AverageGrade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    JOIN Courses c ON sc.CourseID = c.CourseID
    GROUP BY s.Name, c.CourseName
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
averageGradePerStudentInEachCourse()

def topThreeStudentsWithHighestAverageGrades():
    cursor.execute('''
    SELECT s.Name, AVG(sc.Grade) as AverageGrade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    GROUP BY s.Name
    ORDER BY AverageGrade DESC
    LIMIT 3
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
topThreeStudentsWithHighestAverageGrades()

def studentsWithLowestAverageGrade():
    cursor.execute('''
    SELECT s.Name, AVG(sc.Grade) as AverageGrade
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    GROUP BY s.Name
    ORDER BY AverageGrade ASC
    LIMIT 3
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
studentsWithLowestAverageGrade()


def booksNotAssociatedWithAnyCourse():
    cursor.execute('''
    SELECT Title
    FROM Books
    WHERE BookID NOT IN (SELECT DISTINCT BookID FROM CourseBooks)
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
booksNotAssociatedWithAnyCourse()

def booksRequiredForEachMajor():
    cursor.execute('''
    SELECT s.Major, b.Title
    FROM Students s
    JOIN StudentCourses sc ON s.StudentID = sc.StudentID
    JOIN Courses c ON sc.CourseID = c.CourseID
    JOIN CourseBooks cb ON c.CourseID = cb.CourseID
    JOIN Books b ON cb.BookID = b.BookID
    ''')
    results = cursor.fetchall()
    for result in results:
        print(result)
booksRequiredForEachMajor()

#closing connection
connection.close()