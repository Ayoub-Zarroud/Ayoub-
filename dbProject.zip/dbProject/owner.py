import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

connection = sqlite3.connect('db/student_info_system.db')
cursor = connection.cursor()

def execute_query(query, params=()):
    try:
        cursor.execute(query, params)
        connection.commit()
        return cursor.fetchall()
    except sqlite3.Error as e:
        messagebox.showerror("Error", str(e))
        return []

def update_treeview(tree, results, columns):
    tree.delete(*tree.get_children())
    tree["columns"] = columns
    tree["show"] = "headings"
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=100)
    for result in results:
        tree.insert("", "end", values=result)

def add_student(student_id, name, enrollment_year, major):
    query = '''
    INSERT INTO Students (StudentID, Name, EnrollmentYear, Major)
    VALUES (?, ?, ?, ?)
    '''
    execute_query(query, (student_id, name, enrollment_year, major))
    messagebox.showinfo("Success", "Student added successfully!")
    display_all_students()

def delete_student(student_id):
    query = '''
    DELETE FROM Students
    WHERE StudentID = ?
    '''
    execute_query(query, (student_id,))
    messagebox.showinfo("Success", "Student deleted successfully!")
    display_all_students()

def update_student(student_id, name, enrollment_year, major):
    query = '''
    UPDATE Students
    SET Name = ?, EnrollmentYear = ?, Major = ?
    WHERE StudentID = ?
    '''
    execute_query(query, (name, enrollment_year, major, student_id))
    messagebox.showinfo("Success", "Student information updated successfully!")
    display_all_students()

app = tk.Tk()
app.title("University Management System")

function_frame = tk.Frame(app)
function_frame.pack(fill=tk.BOTH, expand=True)

tk.Label(function_frame, text="Student ID").grid(row=0, column=0)
student_id_entry = tk.Entry(function_frame)
student_id_entry.grid(row=0, column=1)
tk.Label(function_frame, text="Name").grid(row=1, column=0)
name_entry = tk.Entry(function_frame)
name_entry.grid(row=1, column=1)
tk.Label(function_frame, text="Enrollment Year").grid(row=2, column=0)
enrollment_year_entry = tk.Entry(function_frame)
enrollment_year_entry.grid(row=2, column=1)

tk.Label(function_frame, text="Major").grid(row=3, column=0)
major_entry = tk.Entry(function_frame)
major_entry.grid(row=3, column=1)
tk.Button(function_frame, text="Add Student", command=lambda: add_student(student_id_entry.get(), name_entry.get(), enrollment_year_entry.get(), major_entry.get())).grid(row=4, column=0)
tk.Button(function_frame, text="Update Student", command=lambda: update_student(student_id_entry.get(), name_entry.get(), enrollment_year_entry.get(), major_entry.get())).grid(row=4, column=1)
tk.Button(function_frame, text="Delete Student", command=lambda: delete_student(student_id_entry.get())).grid(row=4, column=2)

result_frame = tk.Frame(app)
result_frame.pack(fill=tk.BOTH, expand=True)

result_tree = ttk.Treeview(result_frame)
result_tree.pack(fill=tk.BOTH, expand=True)

def display_all_students():
    query = 'SELECT * FROM Students'
    results = execute_query(query)
    columns = ["StudentID", "Name", "EnrollmentYear", "Major"]
    update_treeview(result_tree, results, columns)

tk.Button(app, text="Display All Students", command=display_all_students).pack()

app.mainloop()
connection.close()
